# GameTool — GitHub Pages

A static, mobile-friendly gaming utility UI.

## Deploy on GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Select the `main` branch and `/root`.
6. Save and open the generated Pages URL.

## Important

This project intentionally does not collect, extract, transmit, or display passwords, cookies, session IDs, access tokens, or other authentication credentials. The processing shown on the page is a safe frontend demo for URLs you are authorized to use.
